﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace clock
{

    public partial class clockForm : Form
    {
        //引入API函数  
        [DllImport("user32 ")]
        public static extern bool LockWorkStation();  //这个是调用windows的系统锁定

        private int second = 0;
        private int mintue = 0;
        private bool isRunning;  //是否已经开始

        public clockForm()
        {
            InitializeComponent();
        }


        private void clockForm_Load(object sender, EventArgs e)
        {
            cmbWorkTime.SelectedIndex = 0;
            cmbRestTime.SelectedIndex = 1;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (isRunning == false)
            {
                timerSecond.Start();
                isRunning = true;
                btnStart.Text = "暂停";
                btnStart.BackColor = Color.DarkSeaGreen;
            }
            else if(isRunning)
            {
                timerSecond.Stop();
                isRunning = false;
                btnStart.Text = "继续";
                btnStart.BackColor = Color.Yellow;
            }

        }

        private void timerSecond_Tick(object sender, EventArgs e)
        {
            second++;
            if (second == 60)
            {
                second = 0;
                mintue++;
            }

            //计时时间到了，自动锁屏，且不到时间打开电脑也无效
            if ((mintue <= (int.Parse(cmbWorkTime.Text) + int.Parse(cmbRestTime.Text) - 1)) && (mintue >= (int.Parse(cmbWorkTime.Text))))
            {
                LockWorkStation();
            }

            //休息时间到了，停止计时
            if (mintue == (int.Parse(cmbWorkTime.Text) + int.Parse(cmbRestTime.Text)))
            {
                TimeUpShouldBeStop();
            }

            //控制当前计时时间的输出格式
            lbltime.Text = string.Format("{0} : {1}", mintue.ToString("00"), second.ToString("00"));
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            TimeUpShouldBeStop();
        }

        private void TimeUpShouldBeStop()
        {
            timerSecond.Stop();
            second = 0;
            mintue = 0;
            isRunning = false;
            btnStart.Text = "开始";
            btnStart.BackColor = Color.Transparent;
            lbltime.Text = string.Format("{0} : {1}", mintue.ToString("00"), second.ToString("00"));
        }

        private void clockForm_SizeChanged(object sender, EventArgs e)
        {
            //判断窗体是否将要最小化
            if (WindowState == FormWindowState.Minimized)
            {
                //隐藏任务区图标
                this.ShowInTaskbar = false;
                //图标显示在托盘区
                notifyIcon.Visible = true;
            }
        }

        private void notifyIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //把最小化的窗体显示出来
                WindowState = FormWindowState.Normal;
                //激活窗体并赋予焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                notifyIcon.Visible = true;
            }
            else
            {
                //激活窗体并赋予焦点
                this.Activate();
                //将窗体置顶
                this.TopMost = true;
                //解除窗体前置
                this.TopMost = false;
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                notifyIcon.Visible = true;

            }
        }
    }
}
